function calcularLitros() {
    // Lê os valores dos campos
    var precoLitro = document.getElementById("preco").value;
    var valorPago = document.getElementById("valor").value;

    // Converte para número decimal
    precoLitro = parseFloat(precoLitro);
    valorPago = parseFloat(valorPago);

    // Verifica se os valores são válidos
    if (isNaN(precoLitro) || isNaN(valorPago) || precoLitro <= 0 || valorPago < 0) {
        document.getElementById("resultado").innerText = "Por favor, preencha os valores corretamente.";
        return;
    }

    // Calcula os litros
    var litros = valorPago / precoLitro;

    // Exibe o resultado
    document.getElementById("resultado").innerText =
        "Você conseguiu colocar " + litros.toFixed(2) + " litros de gasolina no tanque.";
}
