function calcularDias() {
    // Lê os valores do formulário
    var nome = document.getElementById("nome").value;
    var idade = document.getElementById("idade").value;

    // Converte idade para número inteiro
    idade = parseInt(idade);

    // Verifica se os dados são válidos
    if (nome === "" || isNaN(idade) || idade < 0) {
        document.getElementById("mensagem").innerText = "Por favor, preencha os campos corretamente.";
        return;
    }

    // Calcula os dias de vida (365 dias por ano)
    var diasDeVida = idade * 365;

    // Mostra a mensagem personalizada
    document.getElementById("mensagem").innerText =
        nome.toUpperCase() + ", VOCÊ JÁ VIVEU " + diasDeVida + " DIAS.";
}
