function converterTempo() {
    // Lê a quantidade de dias fornecida pelo usuário
    var dias = document.getElementById("dias").value;

    // Converte para número
    dias = parseInt(dias);

    // Verifica se o valor inserido é válido
    if (isNaN(dias) || dias <= 0) {
        document.getElementById("resultado").innerText = "Por favor, insira uma quantidade válida de dias.";
        return;
    }

    // Define a quantidade de dias por ano e por mês (considerando 30 dias por mês)
    var diasPorAno = 365;
    var diasPorMes = 30;

    // Calcula os anos, meses e dias
    var anos = Math.floor(dias / diasPorAno);
    var meses = Math.floor((dias % diasPorAno) / diasPorMes);
    var diasRestantes = dias % diasPorMes;

    // Exibe o resultado
    document.getElementById("resultado").innerText = 
        anos + " anos, " + meses + " meses e " + diasRestantes + " dias.";
}
