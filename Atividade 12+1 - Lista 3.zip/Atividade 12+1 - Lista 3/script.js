function calcularArea() {
    // Lê o valor do raio fornecido pelo usuário
    var raio = document.getElementById("raio").value;

    // Converte o valor do raio para número
    raio = parseFloat(raio);

    // Verifica se o raio é válido
    if (isNaN(raio) || raio <= 0) {
        document.getElementById("resultado").innerText = "Por favor, insira um raio válido.";
        return;
    }

    // Definindo o valor de pi
    var pi = 3.14;

    // Calcula a área da pizza
    var area = pi * Math.pow(raio, 2);

    // Exibe o resultado com duas casas decimais
    document.getElementById("resultado").innerText = 
        "A área da pizza é: " + area.toFixed(2) + " cm²";
}
