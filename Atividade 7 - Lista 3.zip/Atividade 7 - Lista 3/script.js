function calcularDias() {
    // Pega os valores de dia e mês
    var dia = document.getElementById("dia").value;
    var mes = document.getElementById("mes").value;

    // Converte para números inteiros
    dia = parseInt(dia);
    mes = parseInt(mes);

    // Verifica se os valores são válidos
    if (isNaN(dia) || isNaN(mes) || dia < 1 || mes < 1 || mes > 12 || dia < 1 || dia > 30) {
        document.getElementById("resultado").innerText = "Por favor, digite uma data válida.";
        return;
    }

    // Calcula os dias passados
    var diasPassados = (mes - 1) * 30 + dia;

    // Exibe o resultado
    document.getElementById("resultado").innerText =
        "Já se passaram " + diasPassados + " dias desde o início do ano.";
}
