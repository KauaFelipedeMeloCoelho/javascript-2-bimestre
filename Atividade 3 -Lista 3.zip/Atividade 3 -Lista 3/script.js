function calcular() {
    // Lê os valores dos inputs
    var paes = document.getElementById("paes").value;
    var broas = document.getElementById("broas").value;

    // Converte os valores para números inteiros
    paes = parseInt(paes);
    broas = parseInt(broas);

    // Verifica se os valores são válidos
    if (isNaN(paes) || isNaN(broas) || paes < 0 || broas < 0) {
        document.getElementById("resultado").innerText = "Por favor, digite quantidades válidas.";
        return;
    }

    // Preços
    var precoPao = 0.12;
    var precoBroa = 1.50;

    // Cálculos
    var totalPaes = paes * precoPao;
    var totalBroas = broas * precoBroa;
    var totalArrecadado = totalPaes + totalBroas;
    var valorPoupanca = totalArrecadado * 0.10;

    // Exibir os resultados
    var mensagem = "Total arrecadado: R$ " + totalArrecadado.toFixed(2) + "\n" +
                   "Valor para guardar na poupança (10%): R$ " + valorPoupanca.toFixed(2);

    document.getElementById("resultado").innerText = mensagem;
}
