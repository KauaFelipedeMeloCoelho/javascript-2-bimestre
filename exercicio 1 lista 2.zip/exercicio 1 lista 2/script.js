// Função que será chamada quando o botão for clicado
function calcularAumentos() {
    // Pega o valor digitado pelo usuário no campo com id "cotacao"
    var input = document.getElementById("cotacao");
    
    // Converte o valor digitado (que é texto) para número com casas decimais
    var cotacao = parseFloat(input.value);
    
    // Pega a div onde os resultados serão mostrados
    var resultadoDiv = document.getElementById("resultado");

    // Verifica se o valor digitado é um número válido maior que zero
    if (isNaN(cotacao) || cotacao <= 0) {
        resultadoDiv.innerHTML = "<p style='color:red;'>Por favor, digite um valor válido para a cotação do dólar.</p>";
        return; // Sai da função se o valor for inválido
    }

    // Cria uma mensagem com a cotação atual
    var mensagem = "<p>Cotação atual: <strong>R$ " + cotacao.toFixed(2) + "</strong></p>";
    mensagem += "<ul>";

    // Lista dos aumentos que queremos calcular
    var aumentos = [1, 2, 5, 10];

    // Para cada valor da lista, calcula o novo valor e adiciona à mensagem
    for (var i = 0; i < aumentos.length; i++) {
        var percentual = aumentos[i];
        var novoValor = cotacao * (1 + percentual / 100);
        mensagem += "<li>Aumento de " + percentual + "%: R$ " + novoValor.toFixed(2) + "</li>";
    }

    mensagem += "</ul>";

    // Mostra a mensagem dentro da div de resultados
    resultadoDiv.innerHTML = mensagem;
}
