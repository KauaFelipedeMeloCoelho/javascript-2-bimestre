// Função que será chamada quando o botão for clicado
function realizarOperacoes() {
    // Pega os valores dos dois números digitados
    var numero1 = document.getElementById("numero1").value;
    var numero2 = document.getElementById("numero2").value;

    // Converte os valores de texto para números inteiros
    numero1 = parseInt(numero1);
    numero2 = parseInt(numero2);

    // Pega o local onde vamos mostrar o resultado
    var resultadoDiv = document.getElementById("resultado");

    // Verifica se os números são válidos
    if (isNaN(numero1) || isNaN(numero2)) {
        resultadoDiv.innerHTML = "<p style='color:red;'>Por favor, digite dois números válidos.</p>";
        return; // Sai da função se os números não forem válidos
    }

    // Realiza as operações
    var soma = numero1 + numero2;
    var subtracao = numero1 - numero2;
    var multiplicacao = numero1 * numero2;
    var divisao = numero1 / numero2;

    // Exibe os resultados
    resultadoDiv.innerHTML = "<p><strong>Soma:</strong> " + soma + "</p>";
    resultadoDiv.innerHTML += "<p><strong>Subtração:</strong> " + subtracao + "</p>";
    resultadoDiv.innerHTML += "<p><strong>Multiplicação:</strong> " + multiplicacao + "</p>";

    // Verifica se a divisão é válida (não pode dividir por zero)
    if (numero2 === 0) {
        resultadoDiv.innerHTML += "<p><strong>Divisão:</strong> Não é possível dividir por zero.</p>";
    } else {
        resultadoDiv.innerHTML += "<p><strong>Divisão:</strong> " + divisao + "</p>";
    }
}
