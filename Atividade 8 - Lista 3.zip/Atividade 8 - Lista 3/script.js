function calcularVenda() {
    // Lê as quantidades fornecidas pelo usuário
    var quantidadePequena = document.getElementById("pequena").value;
    var quantidadeMedia = document.getElementById("media").value;
    var quantidadeGrande = document.getElementById("grande").value;

    // Converte as quantidades para números inteiros
    quantidadePequena = parseInt(quantidadePequena);
    quantidadeMedia = parseInt(quantidadeMedia);
    quantidadeGrande = parseInt(quantidadeGrande);

    // Verifica se as quantidades são válidas
    if (isNaN(quantidadePequena) || isNaN(quantidadeMedia) || isNaN(quantidadeGrande) || 
        quantidadePequena < 0 || quantidadeMedia < 0 || quantidadeGrande < 0) {
        document.getElementById("resultado").innerText = "Por favor, digite quantidades válidas.";
        return;
    }

    // Preços das camisetas
    var precoPequena = 10.00;
    var precoMedia = 12.00;
    var precoGrande = 15.00;

    // Calcula o valor total
    var total = (quantidadePequena * precoPequena) + (quantidadeMedia * precoMedia) + (quantidadeGrande * precoGrande);

    // Exibe o valor total da venda
    document.getElementById("resultado").innerText = 
        "O valor total da venda será R$ " + total.toFixed(2);
}
