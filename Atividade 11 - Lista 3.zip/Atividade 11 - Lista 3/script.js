function calcularSalario() {
    // Lê o salário inicial informado pelo usuário
    var salario = document.getElementById("salario").value;

    // Converte para número
    salario = parseFloat(salario);

    // Verifica se o valor inserido é válido
    if (isNaN(salario) || salario <= 0) {
        document.getElementById("resultado").innerText = "Por favor, insira um salário válido.";
        return;
    }

    // Aumento de 15%
    var aumento = salario * 0.15;
    var salarioComAumento = salario + aumento;

    // Desconto de 8% de impostos
    var descontoImpostos = salarioComAumento * 0.08;
    var salarioFinal = salarioComAumento - descontoImpostos;

    // Exibe o resultado
    document.getElementById("resultado").innerText =
        "Salário Inicial: R$ " + salario.toFixed(2) + "\n" +
        "Salário com Aumento de 15%: R$ " + salarioComAumento.toFixed(2) + "\n" +
        "Salário Final após Desconto de 8%: R$ " + salarioFinal.toFixed(2);
}
