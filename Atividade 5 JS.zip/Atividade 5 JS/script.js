function calcularMedias() {
    const num1 = parseFloat(document.getElementById('num1').value);
    const num2 = parseFloat(document.getElementById('num2').value);
    const num3 = parseFloat(document.getElementById('num3').value);
    const resultado = document.getElementById('resultado');

    if (isNaN(num1) || isNaN(num2) || isNaN(num3)) {
        resultado.innerHTML = 'Por favor, preencha todos os números corretamente.';
        return;
    }

    const mediaAritmetica = (num1 + num2 + num3) / 3;
    const mediaPonderada = ((num1 * 3) + (num2 * 2) + (num3 * 5)) / (3 + 2 + 5);
    const somaDasMedias = mediaAritmetica + mediaPonderada;
    const mediaDasMedias = somaDasMedias / 2;

    resultado.innerHTML = `
        <p><strong>Média Aritmética:</strong> ${mediaAritmetica.toFixed(2)}</p>
        <p><strong>Média Ponderada (pesos 3, 2 e 5):</strong> ${mediaPonderada.toFixed(2)}</p>
        <p><strong>Soma das Médias:</strong> ${somaDasMedias.toFixed(2)}</p>
        <p><strong>Média das Médias:</strong> ${mediaDasMedias.toFixed(2)}</p>
    `;
}