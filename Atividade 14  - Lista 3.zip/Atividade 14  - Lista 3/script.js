function dividirConta() {
    // Lê o valor total da conta
    var valorTotal = document.getElementById("valor").value;

    // Converte para número
    valorTotal = parseFloat(valorTotal);

    // Verifica se o valor inserido é válido
    if (isNaN(valorTotal) || valorTotal <= 0) {
        document.getElementById("resultado").innerText = "Por favor, insira um valor válido para a conta.";
        return;
    }

    // Calcula o valor que Carlos e André irão pagar (arredondando para baixo para R$X,00)
    var valorCarlos = Math.floor(valorTotal / 3);
    var valorAndre = Math.floor(valorTotal / 3);

    // Calcula o valor que Felipe irá pagar (o restante dos centavos)
    var valorFelipe = valorTotal - (valorCarlos + valorAndre);

    // Exibe os valores a pagar por cada amigo
    document.getElementById("resultado").innerText = 
        "Carlos deve pagar: R$ " + valorCarlos.toFixed(2) + "\n" +
        "André deve pagar: R$ " + valorAndre.toFixed(2) + "\n" +
        "Felipe deve pagar: R$ " + valorFelipe.toFixed(2);
}
