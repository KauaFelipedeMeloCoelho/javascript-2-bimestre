function calcularArea() {
    // Lê os valores digitados pelo usuário
    var largura = document.getElementById("largura").value;
    var comprimento = document.getElementById("comprimento").value;

    // Converte os valores para números
    largura = parseFloat(largura);
    comprimento = parseFloat(comprimento);

    // Verifica se os valores são válidos
    if (isNaN(largura) || isNaN(comprimento)) {
        document.getElementById("resultado").innerText = "Por favor, digite valores válidos.";
        return;
    }

    // Calcula a área
    var area = largura * comprimento;

    // Exibe o resultado
    document.getElementById("resultado").innerText = 
        "A área do terreno é " + area + " metros quadrados.";
}
