function calcularDistancia() {
    // Lê as coordenadas dos pontos
    var x1 = document.getElementById("x1").value;
    var y1 = document.getElementById("y1").value;
    var x2 = document.getElementById("x2").value;
    var y2 = document.getElementById("y2").value;

    // Converte as coordenadas para números
    x1 = parseFloat(x1);
    y1 = parseFloat(y1);
    x2 = parseFloat(x2);
    y2 = parseFloat(y2);

    // Verifica se as coordenadas são válidas
    if (isNaN(x1) || isNaN(y1) || isNaN(x2) || isNaN(y2)) {
        document.getElementById("resultado").innerText = "Por favor, insira valores válidos para todas as coordenadas.";
        return;
    }

    // Aplica a fórmula da distância entre dois pontos
    var distancia = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));

    // Exibe o resultado com duas casas decimais
    document.getElementById("resultado").innerText = "A distância entre os pontos é: " + distancia.toFixed(2);
}
