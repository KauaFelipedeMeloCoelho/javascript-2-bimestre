function separarNumero() {
    // Lê o número fornecido pelo usuário
    var numero = document.getElementById("numero").value;

    // Converte para número inteiro
    numero = parseInt(numero);

    // Verifica se o número é válido e está dentro do intervalo esperado (0 a 999)
    if (isNaN(numero) || numero < 0 || numero > 999) {
        document.getElementById("resultado").innerText = "Por favor, insira um número válido de até três dígitos.";
        return;
    }

    // Calcula as centenas, dezenas e unidades
    var centena = Math.floor(numero / 100);  // Pega a centena
    var dezena = Math.floor((numero % 100) / 10);  // Pega a dezena
    var unidade = numero % 10;  // Pega a unidade

    // Exibe o resultado
    document.getElementById("resultado").innerText =
        "CENTENA = " + centena + "\n" +
        "DEZENA = " + dezena + "\n" +
        "UNIDADE = " + unidade;
}
