function reajustarSaldo() {
    const saldo = parseFloat(document.getElementById('saldo').value);
    const resultado = document.getElementById('resultado');

    if (isNaN(saldo)) {
        resultado.textContent = 'Por favor, informe um saldo válido.';
        return;
    }

    const saldoReajustado = saldo * 1.01;
    resultado.textContent = `Saldo com reajuste de 1%: R$ ${saldoReajustado.toFixed(2)}`;
}