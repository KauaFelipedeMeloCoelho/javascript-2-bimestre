function calcularFerraduras() {
    // Pega o valor digitado
    var cavalos = document.getElementById("cavalos").value;

    // Converte para número
    cavalos = parseInt(cavalos);

    // Verifica se é um número válido
    if (isNaN(cavalos) || cavalos < 0) {
        document.getElementById("resultado").innerText = "Por favor, digite um número válido de cavalos.";
        return;
    }

    // Cada cavalo precisa de 4 ferraduras
    var ferraduras = cavalos * 4;

    // Exibe o resultado
    document.getElementById("resultado").innerText = 
        "Você precisa de " + ferraduras + " ferraduras para " + cavalos + " cavalos.";
}
