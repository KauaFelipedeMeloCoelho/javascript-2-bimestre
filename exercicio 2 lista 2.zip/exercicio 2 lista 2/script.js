// Quando o botão for clicado, a função abaixo será executada
function calcularIngredientes() {
    // Pega o número de pessoas digitado no campo de entrada
    var numeroPessoas = document.getElementById("numeroPessoas").value;

    // Converte esse valor para um número inteiro
    numeroPessoas = parseInt(numeroPessoas);

    // Pega o local onde vamos mostrar o resultado
    var resultadoDiv = document.getElementById("resultado");

    // Verifica se o número de pessoas é válido (se é um número e maior que 0)
    if (numeroPessoas <= 0 || isNaN(numeroPessoas)) {
        resultadoDiv.innerHTML = "<p style='color:red;'>Por favor, digite um número válido de pessoas.</p>";
        return; // Sai da função se o número for inválido
    }

    // Quantidade de ovos e queijo por pessoa
    var ovosPorPessoa = 2;
    var queijoPorPessoa = 50; // 50 gramas de queijo por pessoa

    // Calcula o total de ovos e queijo necessários para as pessoas
    var totalOvos = ovosPorPessoa * numeroPessoas;
    var totalQueijo = queijoPorPessoa * numeroPessoas;

    // Exibe o resultado de maneira simples
    resultadoDiv.innerHTML = "<p>Para " + numeroPessoas + " pessoa(s), você precisará de:</p>";
    resultadoDiv.innerHTML += "<ul>";
    resultadoDiv.innerHTML += "<li>" + totalOvos + " ovos</li>";
    resultadoDiv.innerHTML += "<li>" + totalQueijo + " gramas de queijo</li>";
    resultadoDiv.innerHTML += "</ul>";
}
