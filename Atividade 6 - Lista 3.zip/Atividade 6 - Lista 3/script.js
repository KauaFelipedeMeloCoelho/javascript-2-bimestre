function calcularValor() {
    // Pega o valor do campo de entrada
    var peso = document.getElementById("peso").value;

    // Converte o valor para número decimal
    peso = parseFloat(peso);

    // Verifica se o peso é um número válido
    if (isNaN(peso) || peso <= 0) {
        document.getElementById("resultado").innerText = "Por favor, digite um peso válido.";
        return;
    }

    // Define o preço por quilo
    var precoPorQuilo = 12.00;

    // Calcula o valor a pagar
    var valor = peso * precoPorQuilo;

    // Mostra o resultado formatado com 2 casas decimais
    document.getElementById("resultado").innerText = 
        "O valor a pagar é R$ " + valor.toFixed(2);
}
