// Função que será chamada quando o botão for clicado
function calcularTotal() {
    // Pega os valores dos sabores de pizza digitados
    var sabor1 = document.getElementById("sabor1").value;
    var sabor2 = document.getElementById("sabor2").value;
    var sabor3 = document.getElementById("sabor3").value;
    var sabor4 = document.getElementById("sabor4").value;

    // Pega o valor digitado para a quantidade de refrigerantes
    var quantidadeRefrigerantes = document.getElementById("refrigerantes").value;

    // Converte a quantidade de refrigerantes para número inteiro
    quantidadeRefrigerantes = parseInt(quantidadeRefrigerantes);

    // Pega o local onde vamos exibir o resultado
    var resultadoDiv = document.getElementById("resultado");

    // Verifica se os sabores de pizza e a quantidade de refrigerantes são válidos
    if (sabor1 === "" || sabor2 === "" || sabor3 === "" || sabor4 === "") {
        resultadoDiv.innerHTML = "<p style='color:red;'>Por favor, preencha todos os campos de sabores de pizza.</p>";
        return; // Sai da função se algum sabor estiver vazio
    }

    if (isNaN(quantidadeRefrigerantes) || quantidadeRefrigerantes < 0) {
        resultadoDiv.innerHTML = "<p style='color:red;'>Por favor, digite um número válido de refrigerantes.</p>";
        return; // Sai da função se a quantidade de refrigerantes não for válida
    }

    // Preços
    var precoPizza = 12.00; // Cada sabor de pizza custa R$12,00
    var precoRefrigerante = 7.00; // Cada refrigerante custa R$7,00

    // Calcula o total de pizzas e refrigerantes
    var totalPizzas = 4 * precoPizza;
    var totalRefrigerantes = quantidadeRefrigerantes * precoRefrigerante;

    // Calcula o valor total
    var total = totalPizzas + totalRefrigerantes;

    // Exibe os sabores escolhidos e o valor total
    resultadoDiv.innerHTML = "<h2>Seu Pedido:</h2>";
    resultadoDiv.innerHTML += "<p>Sabores de pizza escolhidos:</p>";
    resultadoDiv.innerHTML += "<ul>";
    resultadoDiv.innerHTML += "<li>" + sabor1 + "</li>";
    resultadoDiv.innerHTML += "<li>" + sabor2 + "</li>";
    resultadoDiv.innerHTML += "<li>" + sabor3 + "</li>";
    resultadoDiv.innerHTML += "<li>" + sabor4 + "</li>";
    resultadoDiv.innerHTML += "</ul>";

    resultadoDiv.innerHTML += "<p><strong>Total a pagar:</strong> R$ " + total.toFixed(2) + "</p>";
}
